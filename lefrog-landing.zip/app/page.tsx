"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  Star,
  HeadphonesIcon,
  ArrowRight,
  Check,
  Printer,
  Layers,
  Zap,
  MapPin,
  Phone,
  MessageCircle,
  Upload,
  Search,
  Package,
  Truck,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Award,
  Clock,
  Shield,
} from "lucide-react"
import { useState } from "react"

export default function HomePage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border shadow-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shadow-sm">
              <span className="text-primary-foreground font-bold text-xl">L</span>
            </div>
            <span className="text-2xl font-bold text-foreground">Lefrog.shop</span>
          </div>
          <div className="flex items-center space-x-4">
            <nav className="hidden md:flex items-center space-x-8">
              {["Servicios", "Proceso", "Galería", "FAQ", "Contacto"].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-muted-foreground hover:text-primary transition-colors font-medium"
                >
                  {item}
                </a>
              ))}
            </nav>
            <ThemeToggle />
            <Button
              variant="default"
              className="bg-secondary hover:bg-secondary/90 text-secondary-foreground"
              onClick={() => document.getElementById("contacto")?.scrollIntoView({ behavior: "smooth" })}
            >
              Cotizar Proyecto
            </Button>
          </div>
        </div>
      </header>

      <section className="relative py-32 px-4 text-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="/modern-3d-printer-workspace-with-orange-lighting-a.jpg"
            alt="Taller de impresión 3D profesional"
            className="w-full h-full object-cover opacity-40 dark:opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/70 to-background/80" />
        </div>

        <div className="container mx-auto max-w-6xl relative z-10">
          <Badge variant="secondary" className="mb-8 px-6 py-3 text-sm font-medium bg-accent text-white border-0">
            <Sparkles className="w-4 h-4 mr-2" />
            🇨🇱 Servicio de Impresión 3D Profesional en Chile
          </Badge>

          <h1 className="text-6xl md:text-7xl font-bold text-balance mb-8 leading-tight">
            Impresión 3D de <span className="text-accent">Calidad Industrial</span>
            <br />
            <span className="text-primary">en Chile</span>
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground mb-12 text-pretty max-w-4xl mx-auto leading-relaxed">
            Transformamos tus ideas en realidad con tecnología de impresión 3D de última generación.
            <span className="text-primary font-semibold"> Precisión profesional</span>, entregas rápidas y
            <span className="text-accent font-semibold"> calidad garantizada</span>.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-16">
            <Button
              size="lg"
              className="text-lg px-12 py-4 bg-secondary hover:bg-secondary/90 text-secondary-foreground shadow-lg"
              onClick={() => document.getElementById("contacto")?.scrollIntoView({ behavior: "smooth" })}
            >
              Solicitar Cotización
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="text-lg px-12 py-4 border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
              onClick={() => document.getElementById("galeria")?.scrollIntoView({ behavior: "smooth" })}
            >
              Ver Proyectos
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex items-center justify-center space-x-3 text-muted-foreground">
              <Award className="h-6 w-6 text-accent" />
              <span className="font-medium">Calidad Certificada</span>
            </div>
            <div className="flex items-center justify-center space-x-3 text-muted-foreground">
              <Clock className="h-6 w-6 text-accent" />
              <span className="font-medium">Entrega en 24-48h</span>
            </div>
            <div className="flex items-center justify-center space-x-3 text-muted-foreground">
              <Shield className="h-6 w-6 text-accent" />
              <span className="font-medium">Garantía Incluida</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 px-4 bg-card">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              ¿Por Qué Elegir <span className="text-accent">Lefrog.shop</span>?
            </h2>
            <p className="text-muted-foreground text-xl max-w-3xl mx-auto text-pretty leading-relaxed">
              Combinamos experiencia técnica con tecnología de vanguardia para entregar resultados excepcionales
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Zap, title: "Entrega Rápida", desc: "2-5 días hábiles", color: "text-accent" },
              { icon: Layers, title: "Alta Precisión", desc: "Resolución 0.1mm", color: "text-accent" },
              { icon: HeadphonesIcon, title: "Asesoría Técnica", desc: "Soporte especializado", color: "text-accent" },
              { icon: Check, title: "Calidad Garantizada", desc: "Satisfacción 100%", color: "text-accent" },
            ].map((item, i) => (
              <Card key={i} className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                <CardContent className="pt-8 pb-6">
                  <div className="w-16 h-16 bg-accent/10 rounded-xl flex items-center justify-center mx-auto mb-6">
                    <item.icon className={`h-8 w-8 ${item.color}`} />
                  </div>
                  <h3 className="font-bold text-lg mb-2 text-primary">{item.title}</h3>
                  <p className="text-muted-foreground font-medium">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="py-24 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Nuestros <span className="text-primary">Servicios</span>
            </h2>
            <p className="text-muted-foreground text-xl max-w-3xl mx-auto text-pretty leading-relaxed">
              Soluciones completas de impresión 3D para todos tus proyectos
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              {
                title: "Prototipos Rápidos",
                description: "Desarrollo de prototipos funcionales para validar tus diseños",
                price: "Desde $15.000",
                features: ["PLA/ABS/PETG", "Resolución 0.2mm", "Entrega 2-3 días"],
                materials: "PLA, ABS, PETG",
              },
              {
                title: "Piezas Funcionales",
                description: "Impresión de piezas de reemplazo y componentes resistentes",
                price: "Desde $25.000",
                features: ["Materiales técnicos", "Alta resistencia", "Tolerancias precisas"],
                materials: "ABS, PETG, Nylon",
              },
              {
                title: "Impresión en Resina",
                description: "Detalles ultra finos para joyería, miniaturas y alta precisión",
                price: "Desde $20.000",
                features: ["Resolución 0.05mm", "Acabado liso", "Ideal para detalles"],
                materials: "Resina estándar, flexible",
              },
              {
                title: "Proyectos Personalizados",
                description: "Diseño y fabricación de objetos únicos adaptados a tus necesidades",
                price: "Cotización",
                features: ["Diseño incluido", "Múltiples materiales", "Acabados especiales"],
                materials: "Todos los disponibles",
              },
            ].map((service, i) => (
              <Card key={i} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <Badge variant="secondary" className="bg-accent/10 text-accent border-accent/20">
                      Popular
                    </Badge>
                    <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
                      <Printer className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold">{service.title}</CardTitle>
                  <CardDescription className="text-pretty text-base leading-relaxed">
                    {service.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="text-3xl font-bold text-primary">{service.price}</div>
                    <div className="text-sm text-muted-foreground">
                      <strong className="text-foreground">Materiales:</strong> {service.materials}
                    </div>
                    <ul className="space-y-3">
                      {service.features.map((feature, j) => (
                        <li key={j} className="flex items-center text-sm">
                          <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                            <Check className="h-3 w-3 text-white" />
                          </div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="galeria" className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Galería de Proyectos</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
              Proyectos reales realizados para nuestros clientes
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Prototipo de Drone Racing",
                category: "Aeronáutica",
                material: "PLA Negro",
                description: "Chasis completo para drone de carreras, peso optimizado",
                image: "/drone-racing-frame-3d-printed-black-pla-lightweigh.jpg",
              },
              {
                title: "Repuesto Automotriz BMW",
                category: "Automotriz",
                material: "ABS Gris",
                description: "Soporte de espejo retrovisor, resistente a temperatura",
                image: "/bmw-car-mirror-bracket-3d-printed-grey-abs-automot.jpg",
              },
              {
                title: "Miniatura Arquitectónica",
                category: "Arquitectura",
                material: "Resina Blanca",
                description: "Maqueta de edificio residencial, detalles ultra finos",
                image: "/architectural-building-model-white-resin-3d-printe.jpg",
              },
              {
                title: "Prótesis de Mano",
                category: "Médico",
                material: "PLA+ Skin",
                description: "Prótesis funcional personalizada, articulaciones móviles",
                image: "/prosthetic-hand-3d-printed-pla-skin-color-function.jpg",
              },
              {
                title: "Herramienta Industrial",
                category: "Industrial",
                material: "PETG Transparente",
                description: "Guía de corte personalizada para producción en serie",
                image: "/industrial-cutting-guide-transparent-petg-3d-print.jpg",
              },
              {
                title: "Joyería Artesanal",
                category: "Arte",
                material: "Resina Casteable",
                description: "Anillo con diseño orgánico para fundición en plata",
                image: "/organic-ring-design-castable-resin-3d-printed-jewe.jpg",
              },
            ].map((project, i) => (
              <Card key={i} className="group hover:shadow-lg transition-shadow overflow-hidden">
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="text-xs">
                      {project.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground font-medium">{project.material}</span>
                  </div>
                  <h3 className="font-semibold mb-2 text-balance">{project.title}</h3>
                  <p className="text-sm text-muted-foreground text-pretty">{project.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section id="proceso" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Nuestro <span className="text-accent">Proceso</span> de Trabajo
            </h2>
            <p className="text-muted-foreground text-xl max-w-3xl mx-auto text-pretty leading-relaxed">
              Un proceso simple y transparente para llevar tu proyecto desde la idea hasta la realidad
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Envío de Archivo",
                description: "Envías tu archivo 3D (STL, OBJ) o nos describes tu proyecto",
                icon: Upload,
                time: "Inmediato",
              },
              {
                step: "02",
                title: "Análisis y Cotización",
                description: "Analizamos tu proyecto y te enviamos cotización detallada",
                icon: Search,
                time: "2-4 horas",
              },
              {
                step: "03",
                title: "Impresión",
                description: "Una vez aprobado, iniciamos la impresión con el material seleccionado",
                icon: Package,
                time: "1-3 días",
              },
              {
                step: "04",
                title: "Entrega",
                description: "Empacamos cuidadosamente y enviamos o coordinamos retiro",
                icon: Truck,
                time: "1-2 días",
              },
            ].map((step, i) => (
              <div key={i} className="text-center relative">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4 relative z-10 shadow-lg">
                  <step.icon className="h-8 w-8 text-white" />
                </div>
                <div className="absolute top-8 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-xs font-bold px-2 py-1 rounded-full z-20">
                  {step.step}
                </div>
                {i < 3 && (
                  <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-border -translate-y-1/2 z-0" />
                )}
                <h3 className="font-bold text-lg mb-2 text-primary">{step.title}</h3>
                <p className="text-sm text-muted-foreground mb-3 text-pretty">{step.description}</p>
                <Badge variant="secondary" className="text-xs bg-accent/10 text-accent">
                  {step.time}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-card">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Lo Que Dicen Nuestros Clientes</h2>
            <p className="text-muted-foreground text-lg">Empresas y particulares confían en nuestro servicio</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Carlos Mendoza",
                company: "Startup Tech",
                rating: 5,
                comment: "Excelente calidad en los prototipos. Nos ayudaron a validar nuestro producto rápidamente.",
              },
              {
                name: "María Silva",
                company: "Arquitecta",
                rating: 5,
                comment: "Perfectos para maquetas arquitectónicas. Precisión increíble y buenos precios.",
              },
              {
                name: "Roberto García",
                company: "Maker",
                rating: 5,
                comment: "El mejor servicio de impresión 3D en Chile. Siempre cumplen con los tiempos.",
              },
            ].map((testimonial, i) => (
              <Card key={i} className="hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, j) => (
                      <Star key={j} className="h-4 w-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4 text-pretty">"{testimonial.comment}"</p>
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                      <span className="text-primary font-semibold">{testimonial.name[0]}</span>
                    </div>
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.company}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Preguntas Frecuentes</h2>
            <p className="text-muted-foreground text-lg">Resolvemos las dudas más comunes sobre nuestro servicio</p>
          </div>
          <div className="space-y-4">
            {[
              {
                question: "¿Qué formatos de archivo aceptan?",
                answer:
                  "Aceptamos archivos STL, OBJ, 3MF y PLY. Si tienes tu diseño en otro formato (CAD, SketchUp, etc.), podemos ayudarte con la conversión sin costo adicional.",
              },
              {
                question: "¿Cuánto tiempo toma imprimir mi proyecto?",
                answer:
                  "Los tiempos varían según el tamaño y complejidad. Prototipos simples: 1-2 días. Piezas medianas: 2-3 días. Proyectos complejos: 3-5 días. Siempre te informamos el tiempo exacto en la cotización.",
              },
              {
                question: "¿Qué materiales tienen disponibles?",
                answer:
                  "Contamos con PLA (varios colores), ABS, PETG, TPU (flexible), Nylon, Wood-fill, y resinas (estándar, tough, flexible). Si necesitas un material específico, podemos conseguirlo.",
              },
              {
                question: "¿Hacen envíos a regiones?",
                answer:
                  "Sí, enviamos a todo Chile vía Starken o Chilexpress. Costo de envío desde $3.500 según destino y peso. También puedes retirar en nuestro taller en Providencia.",
              },
              {
                question: "¿Ofrecen garantía en sus trabajos?",
                answer:
                  "Garantizamos la calidad de impresión. Si hay defectos de fabricación, reimprimimos sin costo. Para piezas funcionales, ofrecemos 30 días de garantía contra fallas de material.",
              },
              {
                question: "¿Pueden ayudarme con el diseño?",
                answer:
                  "¡Por supuesto! Ofrecemos servicios de diseño 3D desde $25.000. Trabajamos contigo para crear el modelo perfecto para tu proyecto, optimizado para impresión 3D.",
              },
              {
                question: "¿Cuál es el tamaño máximo que pueden imprimir?",
                answer:
                  "Nuestro volumen máximo es 300x300x400mm. Para proyectos más grandes, podemos dividir el diseño en partes que se ensamblan posteriormente.",
              },
              {
                question: "¿Cómo calculan los precios?",
                answer:
                  "El precio se basa en: material usado (gramos), tiempo de impresión, complejidad del modelo y post-procesado requerido. Siempre recibes una cotización detallada antes de proceder.",
              },
            ].map((faq, i) => (
              <Card
                key={i}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-left">{faq.question}</h3>
                    {openFaq === i ? (
                      <ChevronUp className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                    )}
                  </div>
                </CardHeader>
                {openFaq === i && (
                  <CardContent className="pt-0">
                    <p className="text-muted-foreground text-pretty">{faq.answer}</p>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contacto" className="py-20 px-4 bg-card">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Solicita tu <span className="text-accent">Cotización</span>
            </h2>
            <p className="text-muted-foreground text-xl max-w-3xl mx-auto text-pretty leading-relaxed">
              Cuéntanos sobre tu proyecto y te responderemos en menos de 2 horas
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            {/* Contact Info Cards */}
            <div className="space-y-4">
              <Card className="p-6 text-center shadow-lg border-0">
                <Phone className="h-8 w-8 text-accent mx-auto mb-3" />
                <h3 className="font-bold text-lg mb-2 text-primary">WhatsApp</h3>
                <p className="text-muted-foreground">+56 9 1234 5678</p>
              </Card>
              <Card className="p-6 text-center shadow-lg border-0">
                <MapPin className="h-8 w-8 text-accent mx-auto mb-3" />
                <h3 className="font-bold text-lg mb-2 text-primary">Ubicación</h3>
                <p className="text-muted-foreground">Providencia, Santiago</p>
              </Card>
              <div className="bg-accent/5 border border-accent/20 rounded-lg p-6 text-center">
                <p className="text-sm text-muted-foreground mb-2">Rango típico</p>
                <p className="text-2xl font-bold text-accent">$15.000 - $50.000</p>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card className="p-8 shadow-lg border-0">
                <h3 className="font-bold text-xl mb-6 text-primary">Cotiza tu proyecto</h3>
                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input placeholder="Nombre" required className="h-12" />
                    <Input placeholder="Email" type="email" required className="h-12" />
                  </div>
                  <Input placeholder="Teléfono" className="h-12" />
                  <Textarea
                    placeholder="Describe tu proyecto: tipo de pieza, dimensiones, material preferido, cantidad, fecha de entrega..."
                    rows={4}
                    required
                    className="resize-none"
                  />
                  <Button
                    className="w-full h-12 bg-secondary hover:bg-secondary/90 text-secondary-foreground text-lg font-semibold"
                    size="lg"
                  >
                    Solicitar Cotización Gratuita
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </form>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-16 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-lg">L</span>
                </div>
                <span className="text-xl font-bold">Lefrog.shop</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Servicio profesional de impresión 3D en Chile. Transformamos tus ideas en realidad.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contacto</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>WhatsApp: +56 9 1234 5678</li>
                <li>Providencia, Santiago</li>
                <li>Lun - Vie: 9:00 - 18:00</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Enlaces</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <a href="#servicios" className="hover:text-foreground transition-colors">
                    Servicios
                  </a>
                </li>
                <li>
                  <a href="#proceso" className="hover:text-foreground transition-colors">
                    Proceso
                  </a>
                </li>
                <li>
                  <a href="#galeria" className="hover:text-foreground transition-colors">
                    Galería
                  </a>
                </li>
                <li>
                  <a href="#faq" className="hover:text-foreground transition-colors">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#contacto" className="hover:text-foreground transition-colors">
                    Contacto
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 Lefrog.shop - Servicio de Impresión 3D en Chile. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>

      <div className="fixed bottom-6 right-6 z-50">
        <Button
          size="lg"
          className="rounded-full w-16 h-16 bg-green-500 hover:bg-green-600 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-110"
          onClick={() =>
            window.open(
              "https://wa.me/56912345678?text=Hola, me interesa cotizar un proyecto de impresión 3D",
              "_blank",
            )
          }
        >
          <MessageCircle className="h-7 w-7 text-white" />
        </Button>
      </div>
    </div>
  )
}

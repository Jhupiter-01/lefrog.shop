import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import "./globals.css"

export const metadata: Metadata = {
  title: "Lefrog.shop - Servicio de Impresión 3D Profesional en Chile",
  description:
    "Servicio profesional de impresión 3D en Chile. Prototipos rápidos, piezas funcionales y proyectos personalizados con calidad garantizada.",
  keywords:
    "impresión 3D Chile, prototipos rápidos, impresión 3D Santiago, servicio impresión 3D, piezas 3D, lefrog, impresora 3D profesional, PLA ABS PETG, resina 3D",
  authors: [{ name: "Lefrog.shop" }],
  creator: "Lefrog.shop",
  publisher: "Lefrog.shop",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "es_CL",
    url: "https://lefrog.shop",
    siteName: "Lefrog.shop",
    title: "Lefrog.shop - Servicio de Impresión 3D en Chile",
    description:
      "Servicio profesional de impresión 3D en Chile. Prototipos, piezas funcionales y proyectos personalizados.",
    images: [
      {
        url: "/og-image-3d.jpg",
        width: 1200,
        height: 630,
        alt: "Lefrog.shop - Servicio de Impresión 3D en Chile",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Lefrog.shop - Impresión 3D Profesional Chile",
    description:
      "Servicio profesional de impresión 3D en Chile. Prototipos, piezas funcionales y proyectos personalizados.",
    images: ["/og-image-3d.jpg"],
  },
  verification: {
    google: "google-site-verification-code",
  },
  generator: "Next.js",
  applicationName: "Lefrog.shop",
  referrer: "origin-when-cross-origin",
  category: "manufacturing",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable}`}>
        <Suspense fallback={null}>{children}</Suspense>
        <Analytics />
      </body>
    </html>
  )
}
